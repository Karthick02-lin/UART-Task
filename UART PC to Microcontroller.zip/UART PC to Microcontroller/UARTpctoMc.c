#include<reg51.h>
#include<stdio.h>

void UART_Init(unsigned int baudrate)
{
 unsigned int reload_value; // Calculate the reload value for TH1 
reload_value = 256 - (11059200 / (32 * baudrate)); 
TMOD = 0x20; // Timer 1 in Mode 2 (8-bit auto-reload) 
TH1 = reload_value; // Load the reload value in TH1 register
 SCON = 0x50; // UART mode 1 (8-bit) and enable receiver
 TR1 = 1; 
}   
 
unsigned char recieve()
{
unsigned char sav;
while(RI==0);
sav=SBUF;
RI=0;
return(sav);
}
 

void UARTrecString(char *str) 
{
 while (*str) 
{
 SBUF = *str++; // Load the data into UART transmit buffer 
while(!TI); // Wait until transmission is complete 
TI = 0; // Clear the transmit interrupt flag } } 
}
}
 
void main()
{
	unsigned int baudrate = 9600;
	char buffer[40];
  UART_Init(baudrate);
	sprintf(buffer, "Baud Rate: %u bps\r\r\r", baudrate);
	UARTrecString(buffer);
  UART_Init();
	SCON=0X50;
  TMOD=0X20;
  TH1=0Xf4;//baud rate 2400
  TR1=1;//start timer
while(1)
{
 P3=receive();
}
}
 