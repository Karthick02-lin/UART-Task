#include<reg51.h>
#include<stdio.h>
#include "i2c.h"
sbit SDA = P3^7; // Define SDA pin 
sbit SCL = P2^6;
#define EEPROM_ADDR 0xA0  


void i2c_delay() 
	{
    unsigned int i;
    for (i = 0; i < 100; i++);
}
	
void i2c_init()
 { 
  SDA=1; 
  SCL=1; 
 }
	
void i2c_start() 
	{
    SDA=1;
    SCL=1;
    i2c_delay();
    SDA = 0;
    i2c_delay();
    SCL = 0;
}

void i2c_stop() 
	{
    SDA=0;
    SCL=1;
    i2c_delay();
    SDA = 1;
    i2c_delay();
}

void i2c_write(unsigned char dat) 
	{
    unsigned char i;
    for (i = 0; i < 8; i++) 
		{
        SDA=(dat & 0x80) >> 7;
        dat <<= 1;
        SCL = 1;
        i2c_delay();
        SCL = 0;
    }
    SDA=1;
    SCL=1;
    i2c_delay();
    SCL=0;
}

unsigned char i2c_read() 
	{
    unsigned char i, dat = 0;
    SDA = 1; // Set SDA as input
    for (i = 0; i < 8; i++) 
		{
        dat <<= 1;
        SCL=1;
        i2c_delay();
        if (SDA) {
            dat |= 1;
        }
        SCL=0;
    }
    return dat;
}

void i2c_ack() 
	{
    SDA = 0;
    SCL = 1;
    i2c_delay();
    SCL = 0;
}

void i2c_nack() 
	{
    SDA = 1;
    SCL = 1;
    i2c_delay();
    SCL=0;
}

void EEPROM_Write(unsigned char addr, unsigned char dat) 
	{
    i2c_start();
    i2c_write(EEPROM_ADDR); // Send control byte with write operation
    i2c_write(addr);  // Send EEPROM address
    i2c_write(dat);  // Send data
    i2c_stop();
}

unsigned char EEPROM_Read(unsigned char addr) 
	{
    unsigned char dat;
    i2c_start();
    i2c_write(EEPROM_ADDR & 0xFE); // Send control byte with write operation
    i2c_write(addr);  // Send EEPROM address
    i2c_start();
    i2c_write(EEPROM_ADDR | 0x01); // Send control byte with read operation
    dat = i2c_read();  // Read data from EEPROM
    i2c_nack();  // Send NACK to end read operation
    i2c_stop();
    return dat;
}
	
void UART_Receive_ISR() interrupt 4
 { 
static unsigned char address = 0; // EEPROM memory address
unsigned char rec; 
if (RI) 
{ 
RI = 0; // Clear receive interrupt flag
 rec = SBUF;
 // Read received data
 EEPROM_Write(address,rec); // Write received data to EEPROM 
address++; // Increment address for next data 
if (address >= 256) 
address = 0;
}

 } 



void send(unsigned char *s)
{
    while(*s) 
			{
        SBUF=*s++;
        while(TI==0);
        TI=0;
    }

}

void delay()
{
    unsigned int delay;
    for(delay=0;delay<=6000;delay++);
}

	void UARTInit(unsigned int baudrate) 
{ 
	unsigned int reload_value; // Calculate the reload value for TH1 
reload_value = 256 - (11059200 / (32 * baudrate)); 
TMOD = 0x20; // Timer 1 in Mode 2 (8-bit auto-reload) 
TH1 = reload_value; // Load the reload value in TH1 register
 SCON = 0x50; // UART mode 1 (8-bit) and enable receiver
 TR1 = 1; 
}

void UARTSendString(char *str) 
{
 while (*str) 
{
 SBUF = *str++; // Load the data into UART transmit buffer 
while(!TI); // Wait until transmission is complete 
TI = 0; // Clear the transmit interrupt flag } } 
}
}

void main()
{
    unsigned int i;
	  unsigned int baudrate = 2400;
	  char buffer[40];
    UARTInit(baudrate);
		sprintf(buffer, "Baud Rate: %u bps\r\r\r", baudrate);
    UARTSendString(buffer);
	  i2c_init();  
    EA = 1; 
    ES = 1;
    SCON=0x50;
    TMOD=0x20;
    TH1=TL1=0xfd;	
    TR1=1;
	  
    while(1) 
			{
        send("Finance Minister Arun Jaitley Tuesday hit out at former RBI governor Raghuram Rajan for predicting that the next banking crisis would be triggered by MSME lending, saying postmortem is easier than taking action when it was required.\r");
			  delay();
			  send("Rajan, who had as the chief economist at IMF warned of impending financial crisis of 2008, in a note to a parliamentary committee warned against ambitious credit targets and loan waivers, saying that they could be the sources of next banking crisis\r");
			  delay();
			  send("Government should focus on sources of the next crisis, not just the last one.\r");
			  delay();
			  send("In particular, government should refrain from setting ambitious credit targets or waiving loans. Credit targets are sometimes achieved by abandoning appropriate due diligence, creating the environment for future NPAs,\r");
			  delay();
			  send("Rajan said in the note.\r");
			  delay();
			  send(" Both MUDRA loans as well as the Kisan Credit Card, while popular, have to be examined more closely for potential credit risk.");
			  delay();
				send("Rajan, who was RBI governor for three years till September 2016, is currently.\r\r\r");
				delay();
        UARTSendString(buffer);					
        for(i=0; i<=35000; i++);
			  delay();
				
				
				
    }
		
		
}